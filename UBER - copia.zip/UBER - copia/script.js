// Patrón Estado (State Pattern) - explicación breve:
// - Contexto: la variable `estadoActual` y las funciones que actúan sobre ella
//   representan el 'Context' que mantiene el estado actual del pedido.
// - Estados: cada elemento de `estadosPrincipales` describe un estado
//   (nombre interno + descripción legible). Las acciones que cambian
//   `estadoActual` y llaman a funciones como `actualizarEstado()` o
//   `procesarEstado()` son las transiciones entre estados.
// - Responsabilidad: el patrón separa la lógica de negocio dependiente
//   del estado (por ejemplo, asignar conductor, mover el auto, abrir
//   modales) de la representación del estado en sí. Aquí usamos
//   estructuras y funciones para centralizar las transiciones.
// Nota: Esta implementación es una variante simple y procedural del
// patrón Estado (no se usan objetos/Clases por estado), pero mantiene
// la idea central: comportamiento que depende del estado y transiciones
// gestionadas desde un punto central (`estadoActual`).
;(function () {
  'use strict';

  // Encapsulamos todo el script en un IIFE para evitar contaminar el scope global.
  // Expondremos únicamente las funciones necesarias al final del archivo.

  const estadosPrincipales = [
  ["PedidoIniciado", "El cliente empieza a crear el pedido."],
  ["OrigenSeleccionado", "Punto de partida seleccionado."],
  ["DestinoSeleccionado", "Destino seleccionado."],
  ["TarifaCalculada", "Precio, distancia y tiempo estimado calculados."],
  ["MetodoPagoSeleccionado", "Método de pago seleccionado."],
  ["PedidoConfirmado", "El pedido fue confirmado."],
  ["BuscandoConductor", "Hay alta demanda en tu zona. Te conectaremos pronto."],
  ["ConductorAsignado", "Un conductor aceptó tu pedido."],
  ["ConductorEnCamino", "Tu conductor va hacia el punto de partida."],
  ["ConductorLlego", "Tu conductor llegó al punto de recogida."],
  ["EsperandoCliente", "El conductor espera que abordes el vehículo."],
  ["ClienteAbordo", "El cliente subió al vehículo."],
  ["PedidoEnCurso", "El viaje está en proceso."],
  ["LlegandoDestino", "Estás cerca de tu destino."],
  ["DestinoAlcanzado", "Llegaste al destino."],
  ["PedidoFinalizado", "El conductor finalizó el viaje."],
  ["PagoProcesado", "El sistema cobró el viaje."],
  ["PedidoCalificado", "Cliente y conductor calificaron el viaje."],
  ["PedidoCerrado", "El pedido quedó terminado correctamente."]
];

const nombresEstado = {
  ConductorLlego: "Conductor llegó",
  ClienteAbordo: "Cliente abordó",
  CalculandoRuta: "Calculando ruta",
  PagoRechazado: "Pago rechazado",
  RutaNoDisponible: "Ruta no disponible"
};

const tiposViaje = {
  UberX: {
    nombre: "UberX",
    descripcion: "Viaje economico para hasta 4 personas",
    icono: "fa-car-side",
    base: 52,
    km: 8.8,
    min: 1.7
  },
  Comfort: {
    nombre: "Comfort",
    descripcion: "Autos mas amplios y conductores mejor calificados",
    icono: "fa-car-rear",
    base: 82,
    km: 12.6,
    min: 2.2
  },
  UberXL: {
    nombre: "UberXL",
    descripcion: "Mas espacio para hasta 6 personas",
    icono: "fa-van-shuttle",
    base: 112,
    km: 16.4,
    min: 3.1
  }
};

let estadoActual = "PedidoIniciado";
let flujoActivo = false;
let indiceFlujo = 0;
let intervaloFlujo = null;
let historialEstados = [];
let modoMapa = "origen";
let metodoPagoSeleccionado = "Tarjeta **** 4242";
let tipoViajeSeleccionado = "UberX";
let pagoProcesadoConfirmado = false;
let calificacionCliente = 0;
let calificacionEnviada = false;
let rutaRequestId = 0;
let rutaCalculando = false;
let rutaPorCallesDisponible = false;
let recalculoDestinoEnCurso = false;
let rutaCoords = [];
let progresoCarro = 0;
let animacionCarroId = null;
let animacionFlotaId = null;
let conductorAsignado = null;
let carMarker = null;
let rutaInfo = {
  distanciaKm: 9.8,
  duracionMin: 20
};

let origenCoords = [32.5147, -117.1135];
let destinoCoords = [32.5252, -117.0256];

const estadoTitulo = document.getElementById("estadoTitulo");
const estadoDescripcion = document.getElementById("estadoDescripcion");
const progressBar = document.getElementById("progressBar");
const precioMapa = document.getElementById("precioMapa");
const resumenRuta = document.getElementById("resumenRuta");
const inputOrigen = document.getElementById("origen");
const inputDestino = document.getElementById("destino");
const paymentDropdown = document.getElementById("paymentDropdown");
const selectedPaymentText = document.getElementById("selectedPaymentText");
const fareOptions = document.getElementById("fareOptions");
const fareRouteText = document.getElementById("fareRouteText");
const paymentDecisionModal = document.getElementById("paymentDecisionModal");
const paymentDecisionText = document.getElementById("paymentDecisionText");
const ratingModal = document.getElementById("ratingModal");
const ratingStars = document.getElementById("ratingStars");
const ratingError = document.getElementById("ratingError");
const originModeBtn = document.getElementById("originModeBtn");
const destinationModeBtn = document.getElementById("destinationModeBtn");
const estadoPaso = document.getElementById("estadoPaso");
const stateOptions = document.getElementById("stateOptions");
const backStateBtn = document.getElementById("backStateBtn");
const cancelEventBtn = document.getElementById("cancelEventBtn");
const changeDestinationEventBtn = document.getElementById("changeDestinationEventBtn");
const emergencyEventBtn = document.getElementById("emergencyEventBtn");
const refundEventBtn = document.getElementById("refundEventBtn");
const mapSection = document.querySelector(".map-section");

const map = L.map("map", {
  zoomControl: false
}).setView([32.5007, -117.0301], 12);

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "&copy; OpenStreetMap"
}).addTo(map);

L.control.zoom({
  position: "bottomright"
}).addTo(map);

const origenIcon = L.divIcon({
  className: "custom-marker",
  html: `<div class="map-pin"><i class="fa-solid fa-location-dot" aria-hidden="true"></i></div>`,
  iconSize: [34, 34],
  iconAnchor: [17, 17]
});

const destinoIcon = L.divIcon({
  className: "custom-marker",
  html: `<div class="map-pin destination"><i class="fa-solid fa-flag-checkered" aria-hidden="true"></i></div>`,
  iconSize: [34, 34],
  iconAnchor: [17, 17]
});

const marcadorOrigen = L.marker(origenCoords, {
  icon: origenIcon,
  draggable: true
})
  .addTo(map)
  .bindPopup("<b>Punto de partida</b><br>Real del Mar");

const marcadorDestino = L.marker(destinoCoords, {
  icon: destinoIcon,
  draggable: true
})
  .addTo(map)
  .bindPopup("<b>Destino</b><br>Zona Río");

const rutaInicial = [
  origenCoords,
  [32.5061, -117.1008],
  [32.4948, -117.0852],
  [32.4904, -117.0648],
  [32.5056, -117.0505],
  [32.5169, -117.0358],
  destinoCoords
];

const rutasFlota = [
  [
    [32.5228, -117.1202],
    [32.5164, -117.1088],
    [32.5101, -117.0956],
    [32.5188, -117.0822]
  ],
  [
    [32.5432, -117.0645],
    [32.5338, -117.0466],
    [32.5202, -117.0351],
    [32.5074, -117.0472]
  ],
  [
    [32.4855, -117.0754],
    [32.4936, -117.0602],
    [32.5051, -117.0506],
    [32.5161, -117.0415]
  ],
  [
    [32.5351, -117.1021],
    [32.5268, -117.0874],
    [32.5193, -117.0739],
    [32.5122, -117.0596]
  ],
  [
    [32.4988, -117.1182],
    [32.5055, -117.1057],
    [32.5139, -117.0923],
    [32.5231, -117.0804]
  ],
  [
    [32.4706, -117.0424],
    [32.4835, -117.0361],
    [32.4971, -117.0307],
    [32.5108, -117.0258]
  ]
];

const rutaLayer = L.polyline(rutaInicial, {
  color: "#000",
  weight: 6,
  opacity: 0.9,
  lineCap: "round",
  lineJoin: "round"
}).addTo(map);

const flotaCarros = crearFlotaCarros();

map.fitBounds(rutaLayer.getBounds(), {
  padding: [80, 80]
});

iniciarMovimientoFlota();
seleccionarModoMapa("origen");
actualizarPreciosPorRuta();
renderizarOpcionesEstado();
actualizarRutaReal({ actualizarEstado: false }).finally(renderizarOpcionesEstado);

map.on("click", event => {
  actualizarPuntoMapa(modoMapa, event.latlng);
});

marcadorOrigen.on("dragstart", () => seleccionarModoMapa("origen"));
marcadorOrigen.on("dragend", event => {
  actualizarPuntoMapa("origen", event.target.getLatLng(), { cambiarModo: false });
});

marcadorDestino.on("dragstart", () => seleccionarModoMapa("destino"));
marcadorDestino.on("dragend", event => {
  actualizarPuntoMapa("destino", event.target.getLatLng(), { cambiarModo: false });
});

  // -----------------------------
  // Listeners globales del UI
  // -----------------------------
  // Aquí agrupamos los `addEventListener` que reaccionan a interacciones
  // globales (clicks, teclas, carga de la página, etc.).

inputOrigen.addEventListener("focus", () => seleccionarModoMapa("origen"));
inputDestino.addEventListener("focus", () => seleccionarModoMapa("destino"));

window.addEventListener("load", () => {
  setTimeout(() => map.invalidateSize(), 120);
});

document.addEventListener("click", event => {
  if (!paymentDropdown || paymentDropdown.contains(event.target)) return;

  cerrarMetodoPago();
});

document.addEventListener('keydown', event => {
  if (event.key === 'Escape') {
    cerrarMetodoPago();
    if (ratingModal?.classList.contains('open')) {
      cerrarModalCalificacion();
    }
    return;
  }

  if (ratingModal?.classList.contains('open')) {
    const numero = Number(event.key);
    if (numero >= 1 && numero <= 5) seleccionarCalificacion(numero);
  }
});

function toggleMetodoPago(event) {
  event?.stopPropagation();

  if (!paymentDropdown) return;

  const abierto = paymentDropdown.classList.toggle("open");
  const trigger = paymentDropdown.querySelector(".payment-trigger");
  trigger?.setAttribute("aria-expanded", String(abierto));
}

  // -----------------------------
  // Gestión de métodos de pago
  // -----------------------------
  // Funciones que controlan la UI del selector de método de pago y el
  // flujo para procesar o cancelar el pago.

function cerrarMetodoPago() {
  if (!paymentDropdown) return;

  paymentDropdown.classList.remove("open");
  paymentDropdown
    .querySelector(".payment-trigger")
    ?.setAttribute("aria-expanded", "false");
}

function seleccionarMetodoPago(nombre, icono, event) {
  event?.stopPropagation();

  metodoPagoSeleccionado = nombre;

  if (selectedPaymentText) {
    selectedPaymentText.textContent = nombre;
  }

  const iconoActual = paymentDropdown?.querySelector(".payment-left > i");

  if (iconoActual) {
    iconoActual.className = `fa-solid ${icono}`;
  }

  document.querySelectorAll(".payment-option").forEach(opcion => {
    opcion.classList.toggle("active", opcion.textContent.trim() === nombre);
  });

  if (estadoActual === "MetodoPagoSeleccionado") {
    estadoDescripcion.textContent = obtenerDescripcionEstado(
      "MetodoPagoSeleccionado",
      ""
    );
  }

  if (estadoActual === "PagoProcesado" && !pagoProcesadoConfirmado) {
    estadoDescripcion.textContent = obtenerDescripcionEstado("PagoProcesado", "");

    if (paymentDecisionText) {
      paymentDecisionText.textContent = `Deseas procesar ${precioMapa.textContent} con ${metodoPagoSeleccionado}?`;
    }
  }

  cerrarMetodoPago();
}

function abrirModalCalificacion() {
  calificacionCliente = 0;
  calificacionEnviada = false;
  actualizarEstrellasCalificacion();
  ratingError?.classList.remove("visible");
  ratingModal?.classList.add("open");
  ratingModal?.setAttribute("aria-hidden", "false");
}

function cerrarModalCalificacion() {
  ratingModal?.classList.remove("open");
  ratingModal?.setAttribute("aria-hidden", "true");
}

function seleccionarCalificacion(valor) {
  calificacionCliente = valor;
  ratingError?.classList.remove("visible");
  actualizarEstrellasCalificacion();
}

function actualizarEstrellasCalificacion() {
  if (!ratingStars) return;

  ratingStars.querySelectorAll("button").forEach((boton, index) => {
    boton.classList.toggle("active", index < calificacionCliente);
  });
}

function enviarCalificacion() {
  if (calificacionCliente < 1) {
    ratingError?.classList.add("visible");
    return;
  }

  calificacionEnviada = true;
  cerrarModalCalificacion();
  cambiarEstado(
    "PedidoCalificado",
    `Calificaste el viaje con ${calificacionCliente} estrella${calificacionCliente === 1 ? "" : "s"}.`
  );

  setTimeout(() => {
    cambiarEstado(
      "PedidoCerrado",
      "El pedido quedo terminado correctamente."
    );
    flujoActivo = false;
    indiceFlujo = estadosPrincipales.length;
  }, 900);
}

  // -----------------------------
  // Gestión de calificaciones
  // -----------------------------
  // Abrir/cerrar modal, seleccionar estrellas y enviar la calificación.

function renderizarOpcionesTarifa() {
  if (!fareOptions) return;

  if (fareRouteText) {
    fareRouteText.textContent = `${rutaInfo.distanciaKm.toFixed(1)} km - ${Math.max(1, Math.round(rutaInfo.duracionMin))} min estimados`;
  }

  fareOptions.innerHTML = "";

  Object.entries(tiposViaje).forEach(([id, tipo]) => {
    const boton = document.createElement("button");
    boton.type = "button";
    boton.className = `fare-option ${id === tipoViajeSeleccionado ? "active" : ""}`.trim();
    boton.onclick = () => seleccionarTipoViaje(id);
    boton.innerHTML = `
      <span class="fare-option-icon">
        <i class="fa-solid ${tipo.icono}" aria-hidden="true"></i>
      </span>
      <span>
        <strong>${tipo.nombre}</strong>
        <small>${tipo.descripcion}</small>
      </span>
      <span class="fare-option-price">${calcularRangoPrecio(id)}</span>
    `;
    fareOptions.appendChild(boton);
  });
}

function seleccionarTipoViaje(tipoId) {
  if (!tiposViaje[tipoId]) return;

  tipoViajeSeleccionado = tipoId;
  actualizarPreciosPorRuta();

  if (estadoActual === "TarifaCalculada") {
    estadoDescripcion.textContent = `${tiposViaje[tipoId].nombre} seleccionado por ${calcularRangoPrecio(tipoId)}.`;
  }
}

  // -----------------------------
  // Opciones y renderizado de tarifa
  // -----------------------------
  // Renderiza las opciones de tipo de viaje (UI) y maneja selección.

function abrirModalProcesarPago() {
  pagoProcesadoConfirmado = false;

  if (paymentDecisionText) {
    paymentDecisionText.textContent = `Deseas procesar ${precioMapa.textContent} con ${metodoPagoSeleccionado}?`;
  }

  paymentDecisionModal?.classList.add("open");
  paymentDecisionModal?.setAttribute("aria-hidden", "false");
}

function cerrarModalProcesarPago() {
  paymentDecisionModal?.classList.remove("open");
  paymentDecisionModal?.setAttribute("aria-hidden", "true");
}

function decidirProcesarPago(procesar) {
  cerrarModalProcesarPago();

  if (!procesar) {
    pagoProcesadoConfirmado = false;
    detenerFlujo();
    cambiarEstado(
      "PagoRechazado",
      "El pago no fue procesado. Puedes cambiar el metodo de pago e intentarlo otra vez."
    );
    return;
  }

  pagoProcesadoConfirmado = true;
  cambiarEstado(
    "PagoProcesado",
    `Pago procesado correctamente con ${metodoPagoSeleccionado}.`
  );

  setTimeout(() => {
    cambiarEstado(
      "PedidoCalificado",
      obtenerDescripcionEstado("PedidoCalificado", "")
    );
    abrirModalCalificacion();
  }, 900);
}

function reintentarProcesarPago() {
  cambiarEstado(
    "PagoProcesado",
    obtenerDescripcionEstado("PagoProcesado", "")
  );
  abrirModalProcesarPago();
}

function crearFlotaCarros() {
  const nombres = ["Alex", "Mariana", "Luis", "Diana", "Sergio", "Nora"];

  return rutasFlota.map((ruta, index) => {
    const progresoInicial = index / rutasFlota.length;
    const marker = L.marker(obtenerPuntoEnCoordenadas(ruta, progresoInicial), {
      icon: crearIconoCarro(false),
      zIndexOffset: 250
    })
      .addTo(map)
      .bindPopup(`<b>${nombres[index]}</b><br>Conductor disponible`);

    return {
      id: index + 1,
      nombre: nombres[index],
      ruta,
      marker,
      progreso: progresoInicial,
      velocidad: 0.000015 + index * 0.000003,
      asignado: false,
      distanciaAlOrigen: Infinity
    };
  });
}

function crearIconoCarro(asignado) {
  const claseEstado = asignado ? "assigned-vehicle" : "fleet-vehicle";
  const tamano = asignado ? 46 : 36;
  const ancla = tamano / 2;

  return L.divIcon({
    className: "car-marker",
    html: `<div class="vehicle-badge ${claseEstado}"><i class="fa-solid fa-car-side" aria-hidden="true"></i></div>`,
    iconSize: [tamano, tamano],
    iconAnchor: [ancla, ancla]
  });
}

  // -----------------------------
  // Flota de vehículos y sus iconos
  // -----------------------------
  // Creación de marcadores que representan los vehículos disponibles y
  // utilidades para construir iconos según su estado.

function iniciarMovimientoFlota() {
  let tiempoAnterior = performance.now();

  function moverFlota(tiempoActual) {
    const delta = tiempoActual - tiempoAnterior;
    tiempoAnterior = tiempoActual;

    flotaCarros.forEach(auto => {
      if (auto.asignado) return;

      auto.progreso = (auto.progreso + auto.velocidad * delta) % 1;
      auto.marker.setLatLng(obtenerPuntoEnCoordenadas(auto.ruta, auto.progreso));
    });

    animacionFlotaId = requestAnimationFrame(moverFlota);
  }

  animacionFlotaId = requestAnimationFrame(moverFlota);
}

  // -----------------------------
  // Movimiento y animación de la flota
  // -----------------------------
  // Animación continua que actualiza las posiciones de los marcadores
  // de la flota cuando no están asignados a un pedido.

function seleccionarModoMapa(tipo) {
  modoMapa = tipo;
  originModeBtn.classList.toggle("active", tipo === "origen");
  destinationModeBtn.classList.toggle("active", tipo === "destino");
  mapSection.classList.add("picking");
}

function actualizarPuntoMapa(tipo, latlng, opciones = {}) {
  const { cambiarModo = true } = opciones;
  const coords = normalizarLatLng(latlng);
  const mantieneViajeEnCurso = flujoActivo && recalculoDestinoEnCurso && tipo === "destino";

  if (flujoActivo && !mantieneViajeEnCurso) {
    detenerFlujo();
  }

  if (!mantieneViajeEnCurso) {
    indiceFlujo = 0;
    progressBar.style.width = "0%";
  }

  if (tipo === "origen") {
    origenCoords = coords;
    marcadorOrigen
      .setLatLng(coords)
      .setPopupContent(`<b>Punto de partida</b><br>${formatearCoordenadas(coords)}`);
    inputOrigen.value = `Origen: ${formatearCoordenadas(coords)}`;

    if (cambiarModo) {
      seleccionarModoMapa("destino");
    }
  } else {
    destinoCoords = coords;
    marcadorDestino
      .setLatLng(coords)
      .setPopupContent(`<b>Destino</b><br>${formatearCoordenadas(coords)}`);
    inputDestino.value = `Destino: ${formatearCoordenadas(coords)}`;
  }

  const rutaActualizada = actualizarRutaReal({
    actualizarEstado: !mantieneViajeEnCurso
  });

  if (mantieneViajeEnCurso) {
    recalculoDestinoEnCurso = false;

    rutaActualizada.then(() => {
      if (rutaPorCallesDisponible) {
        cambiarEstado(
          "PedidoEnCurso",
          "Destino actualizado. El viaje continúa."
        );
      }
    });
  }
}

  // -----------------------------
  // Selección de puntos en el mapa
  // -----------------------------
  // Funciones que controlan el modo de marcación (origen/destino) y la
  // actualización de marcadores arrastrables y campos de entrada.

async function actualizarRutaReal(opciones = {}) {
  const { ajustarMapa = true, actualizarEstado = true } = opciones;
  const requestId = ++rutaRequestId;
  const puntos = `${origenCoords[1]},${origenCoords[0]};${destinoCoords[1]},${destinoCoords[0]}`;
  const url = `https://router.project-osrm.org/route/v1/driving/${puntos}?overview=full&geometries=geojson&steps=false`;

  rutaCalculando = true;
  rutaPorCallesDisponible = false;

  if (actualizarEstado) {
    mostrarEstado("CalculandoRuta", "Calculando ruta real por calles...", 10);
  }

  try {
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error("No se pudo consultar el servicio de rutas.");
    }

    const data = await response.json();
    const ruta = data.routes?.[0];

    if (data.code !== "Ok" || !ruta?.geometry?.coordinates?.length) {
      throw new Error("No se encontró una ruta disponible.");
    }

    if (requestId !== rutaRequestId) return;

    rutaCoords = ruta.geometry.coordinates.map(([lng, lat]) => [lat, lng]);
    rutaInfo = {
      distanciaKm: ruta.distance / 1000,
      duracionMin: Math.max(1, Math.round(ruta.duration / 60))
    };
    rutaPorCallesDisponible = true;

    rutaLayer.setLatLngs(rutaCoords);
    actualizarResumenRuta();
    actualizarPreciosPorRuta();

    if (!conductorAsignado || !flujoActivo) {
      moverCarroEnRuta(0, { animar: false });
    }

    if (ajustarMapa) {
      map.fitBounds(rutaLayer.getBounds(), {
        padding: [84, 84]
      });
    }

    if (actualizarEstado) {
      mostrarEstado("TarifaCalculada", obtenerDescripcionEstado("TarifaCalculada", ""), 22);
    }
  } catch (error) {
    if (requestId !== rutaRequestId) return;

    aplicarRutaDirectaTemporal();
    mostrarEstado(
      "RutaNoDisponible",
      "No se pudo calcular una ruta por calles. Intenta con otro punto del mapa.",
      0
    );
  } finally {
    if (requestId === rutaRequestId) {
      rutaCalculando = false;
    }
  }
}

  // -----------------------------
  // Cálculo de ruta (OSRM) y fallback
  // -----------------------------
  // `actualizarRutaReal` consulta el servicio de ruteo y actualiza
  // `rutaCoords` y `rutaInfo`. Si falla, se usa `aplicarRutaDirectaTemporal`.

  function aplicarRutaDirectaTemporal() {
    rutaCoords = [origenCoords, destinoCoords];
    rutaInfo = {
      distanciaKm: calcularDistanciaKm(origenCoords, destinoCoords),
      duracionMin: Math.max(1, Math.round((calcularDistanciaKm(origenCoords, destinoCoords) / 35) * 60))
    };
    rutaPorCallesDisponible = false;
    rutaLayer.setLatLngs(rutaCoords);
    actualizarResumenRuta();
    actualizarPreciosPorRuta();

    if (!conductorAsignado || !flujoActivo) {
      moverCarroEnRuta(0, { animar: false });
    }
  }

// Mostrar/registrar un nuevo estado en el Contexto
// - Esta función es el punto central donde se actualiza `estadoActual`.
// - Guarda historial si corresponde, actualiza la UI (título, descripción,
//   barra de progreso) y ajusta `indiceFlujo` para seguir la secuencia.
// - Actúa como el 'Context.setState(...)' en variantes del patrón Estado,
//   centralizando los efectos secundarios derivados del cambio de estado.
function mostrarEstado(estado, descripcion, progreso = null, opciones = {}) {
  const { guardarHistorial = true } = opciones;
  const estadoAnterior = estadoActual;
  const descripcionAnterior = estadoDescripcion.textContent;
  const progresoAnterior = progressBar.style.width;

  if (guardarHistorial && estadoAnterior && estadoAnterior !== estado) {
    historialEstados.push({
      estado: estadoAnterior,
      descripcion: descripcionAnterior,
      progreso: progresoAnterior
    });
  }

  estadoActual = estado;
  estadoTitulo.textContent = formatearEstado(estado);
  estadoDescripcion.textContent = descripcion;

  const indiceEstado = obtenerIndiceEstado(estado);

  if (indiceEstado !== -1) {
    indiceFlujo = indiceEstado;
  }

  if (progreso !== null) {
    progressBar.style.width = `${progreso}%`;
  }

  renderizarOpcionesEstado();
}

// Interfaz conveniente para cambiar estado
// - Calcula el progreso estimado en la barra (basado en el índice del estado)
//   y delega en `mostrarEstado` para efectuar la transición.
// - Usar `cambiarEstado(...)` desde la lógica de flujo mantiene las
//   transiciones consistentes y evita duplicar cálculos de progreso.
function cambiarEstado(estado, descripcion, opciones = {}) {
  const indiceEstado = obtenerIndiceEstado(estado);
  const progreso = indiceEstado !== -1
    ? ((indiceEstado + 1) / estadosPrincipales.length) * 100
    : parseFloat(progressBar.style.width) || 0;

  mostrarEstado(estado, descripcion, progreso, opciones);
}

  // -----------------------------
  // Gestión de estado (Context emulado)
  // -----------------------------
  // `mostrarEstado` y `cambiarEstado` actúan como el Context del patrón
  // Estado: mantienen el estado actual, historial y disparan efectos UI.

function formatearEstado(texto) {
  if (nombresEstado[texto]) {
    return nombresEstado[texto];
  }

  return texto.replace(/([A-ZÁÉÍÓÚÑ])/g, " $1").trim();
}

function obtenerDescripcionEstado(estado, descripcion) {
  if (estado === "TarifaCalculada") {
    const tipo = tiposViaje[tipoViajeSeleccionado];
    return `${tipo.nombre} seleccionado por ${calcularRangoPrecio(tipoViajeSeleccionado)}.`;
  }

  if (estado === "MetodoPagoSeleccionado") {
    return `Metodo de pago seleccionado: ${metodoPagoSeleccionado}.`;
  }

  if (estado === "PagoProcesado" && !pagoProcesadoConfirmado) {
    return "Confirma si deseas procesar el pago.";
  }

  if (estado === "PedidoCalificado" && !calificacionEnviada) {
    return "Califica el viaje para cerrar el pedido.";
  }

  return descripcion;
}

function iniciarFlujo() {
  if (flujoActivo) return;

  cerrarMetodoPago();

  const origen = inputOrigen.value.trim();
  const destino = inputDestino.value.trim();

  if (!origen || !destino) {
    alert("Completa el punto de partida y destino.");
    return;
  }

  if (rutaCalculando) {
    alert("Espera a que termine el cálculo de la ruta real.");
    return;
  }

  if (!rutaPorCallesDisponible) {
    alert("Primero marca una ruta válida por calles.");
    return;
  }

  detenerAnimacionCarro();
  liberarConductorAsignado();
  flujoActivo = true;
  indiceFlujo = 0;
  progresoCarro = 0;
  pagoProcesadoConfirmado = false;
  calificacionCliente = 0;
  calificacionEnviada = false;
  cerrarModalProcesarPago();
  cerrarModalCalificacion();

  cambiarEstado("PedidoIniciado", "Preparando tu solicitud de viaje...");

  intervaloFlujo = setInterval(() => {
    if (indiceFlujo >= estadosPrincipales.length) {
      clearInterval(intervaloFlujo);
      flujoActivo = false;
      return;
    }

    const [estado, descripcion] = estadosPrincipales[indiceFlujo];
    const descripcionEstado = obtenerDescripcionEstado(estado, descripcion);

    if (estadoActual.includes("Cancelado") || estadoActual.includes("Revision") || estadoActual === "PedidoExpirado" || estadoActual === "PedidoSinConductor") {
      clearInterval(intervaloFlujo);
      flujoActivo = false;
      return;
    }

    // TRANSICIÓN: pedimos el cambio de estado aquí. Esta llamada modifica
    // el `estadoActual` y dispara los efectos secundarios asociados
    // (actualización UI, progreso, historial). En el Patrón Estado, este
    // sería el lugar donde el Context solicita al nuevo State su comportamiento.
    cambiarEstado(estado, descripcionEstado);

    if (estado === "BuscandoConductor") {
      asignarConductorMasCercano();
    }

    if (estado === "ConductorAsignado") {
      const conductor = asignarConductorMasCercano();

      if (conductor) {
        estadoDescripcion.textContent = `${conductor.nombre} acepto tu viaje y va hacia ti.`;
      }
    }

    if (estado === "ConductorEnCamino") {
      if (!conductorAsignado) {
        asignarConductorMasCercano();
      }

      moverCarroAPunto(origenCoords, { duracion: 3000, progresoFinal: 0 });
    }

    if (estado === "PedidoEnCurso") {
      moverCarroEnRuta(0.58, { duracion: 3000 });
    }

    if (estado === "DestinoAlcanzado") {
      moverCarroEnRuta(1, { duracion: 3400 });
    }

    if (estado === "PagoProcesado") {
      clearInterval(intervaloFlujo);
      flujoActivo = false;
      indiceFlujo++;
      abrirModalProcesarPago();
      return;
    }

    if (estado === "PedidoCalificado") {
      clearInterval(intervaloFlujo);
      flujoActivo = false;
      indiceFlujo++;
      abrirModalCalificacion();
      return;
    }

    indiceFlujo++;
  }, 1700);
}

  // -----------------------------
  // Flujo principal del pedido
  // -----------------------------
  // `iniciarFlujo` controla el avance automático del pedido por la lista
  // `estadosPrincipales`. En una versión por clases estas acciones pasarían
  // a los métodos `enter()`/`handle()` de cada `State`.

function moverCarro(coords) {
  if (!carMarker) return;

  carMarker.setLatLng(coords);
}

  // -----------------------------
  // Animación del vehículo asignado
  // -----------------------------
  // Funciones `moverCarro`, `moverCarroAPunto` y `moverCarroEnRuta` se
  // encargan de interpolar y actualizar la posición del marcador del
  // conductor asignado en pantalla.

function moverCarroAPunto(coordsDestino, opciones = {}) {
  if (!carMarker) return;

  const { duracion = 1400, progresoFinal = null } = opciones;
  const inicio = carMarker.getLatLng();
  const destino = L.latLng(coordsDestino);
  const inicioTiempo = performance.now();

  detenerAnimacionCarro();

  function animarPaso(tiempoActual) {
    const avance = Math.min(1, (tiempoActual - inicioTiempo) / duracion);
    const suavizado = suavizarMovimiento(avance);
    const lat = inicio.lat + (destino.lat - inicio.lat) * suavizado;
    const lng = inicio.lng + (destino.lng - inicio.lng) * suavizado;

    moverCarro([lat, lng]);

    if (avance < 1) {
      animacionCarroId = requestAnimationFrame(animarPaso);
      return;
    }

    if (progresoFinal !== null) {
      progresoCarro = limitarProgreso(progresoFinal);
    }

    animacionCarroId = null;
    moverCarro(coordsDestino);
  }

  animacionCarroId = requestAnimationFrame(animarPaso);
}

function moverCarroEnRuta(progresoDestino, opciones = {}) {
  const { animar = true, duracion = 1400 } = opciones;
  const destino = limitarProgreso(progresoDestino);

  detenerAnimacionCarro();

  if (!animar || duracion <= 0) {
    progresoCarro = destino;
    moverCarro(obtenerPuntoRuta(destino));
    return;
  }

  const inicio = progresoCarro;
  const inicioTiempo = performance.now();

  function animarPaso(tiempoActual) {
    const avance = Math.min(1, (tiempoActual - inicioTiempo) / duracion);
    const suavizado = suavizarMovimiento(avance);
    progresoCarro = inicio + (destino - inicio) * suavizado;

    moverCarro(obtenerPuntoRuta(progresoCarro));

    if (avance < 1) {
      animacionCarroId = requestAnimationFrame(animarPaso);
      return;
    }

    progresoCarro = destino;
    animacionCarroId = null;
    moverCarro(obtenerPuntoRuta(destino));
  }

  animacionCarroId = requestAnimationFrame(animarPaso);
}

function detenerAnimacionCarro() {
  if (!animacionCarroId) return;

  cancelAnimationFrame(animacionCarroId);
  animacionCarroId = null;
}

function obtenerPuntoRuta(progreso) {
  return obtenerPuntoEnCoordenadas(rutaCoords.length ? rutaCoords : [origenCoords], progreso);
}

function obtenerPuntoEnCoordenadas(coordenadas, progreso) {
  if (!coordenadas.length) {
    return origenCoords;
  }

  if (coordenadas.length === 1) {
    return coordenadas[0];
  }

  const objetivo = calcularLongitudCoordenadas(coordenadas) * limitarProgreso(progreso);
  let recorrido = 0;

  for (let i = 0; i < coordenadas.length - 1; i++) {
    const puntoA = map.latLngToLayerPoint(coordenadas[i]);
    const puntoB = map.latLngToLayerPoint(coordenadas[i + 1]);
    const longitudSegmento = puntoA.distanceTo(puntoB);

    if (recorrido + longitudSegmento >= objetivo) {
      const restante = objetivo - recorrido;
      const proporcion = longitudSegmento === 0 ? 0 : restante / longitudSegmento;
      const puntoInterpolado = L.point(
        puntoA.x + (puntoB.x - puntoA.x) * proporcion,
        puntoA.y + (puntoB.y - puntoA.y) * proporcion
      );

      return map.layerPointToLatLng(puntoInterpolado);
    }

    recorrido += longitudSegmento;
  }

  return coordenadas[coordenadas.length - 1];
}

function calcularLongitudRuta() {
  return calcularLongitudCoordenadas(rutaCoords);
}

function calcularLongitudCoordenadas(coordenadas) {
  let longitud = 0;

  for (let i = 0; i < coordenadas.length - 1; i++) {
    const puntoA = map.latLngToLayerPoint(coordenadas[i]);
    const puntoB = map.latLngToLayerPoint(coordenadas[i + 1]);
    longitud += puntoA.distanceTo(puntoB);
  }

  return longitud;
}

function limitarProgreso(progreso) {
  return Math.min(1, Math.max(0, progreso));
}

function suavizarMovimiento(valor) {
  return valor < 0.5
    ? 2 * valor * valor
    : 1 - Math.pow(-2 * valor + 2, 2) / 2;
}

function asignarConductorMasCercano() {
  if (conductorAsignado) {
    anunciarConductor(conductorAsignado);
    return conductorAsignado;
  }

  const origenLatLng = L.latLng(origenCoords);
  let conductorCercano = null;
  let distanciaMenor = Infinity;

  flotaCarros.forEach(auto => {
    if (auto.asignado) return;

    const distancia = auto.marker.getLatLng().distanceTo(origenLatLng);

    if (distancia < distanciaMenor) {
      distanciaMenor = distancia;
      conductorCercano = auto;
    }
  });

  if (!conductorCercano) return null;

  conductorCercano.asignado = true;
  conductorCercano.distanciaAlOrigen = distanciaMenor;
  conductorCercano.marker.setIcon(crearIconoCarro(true));
  conductorCercano.marker.setZIndexOffset(900);
  conductorCercano.marker.setPopupContent(
    `<b>${conductorCercano.nombre}</b><br>Conductor asignado`
  );

  conductorAsignado = conductorCercano;
  carMarker = conductorCercano.marker;
  progresoCarro = 0;

  anunciarConductor(conductorCercano);
  return conductorCercano;
}

function anunciarConductor(conductor) {
  const distanciaKm = conductor.distanciaAlOrigen / 1000;
  estadoDescripcion.textContent = `${conductor.nombre} es el conductor mas cercano, a ${distanciaKm.toFixed(1)} km del punto de partida.`;
}

function liberarConductorAsignado() {
  if (!conductorAsignado) {
    carMarker = null;
    return;
  }

  conductorAsignado.asignado = false;
  conductorAsignado.marker.setIcon(crearIconoCarro(false));
  conductorAsignado.marker.setZIndexOffset(250);
  conductorAsignado.marker.setPopupContent(
    `<b>${conductorAsignado.nombre}</b><br>Conductor disponible`
  );
  conductorAsignado = null;
  carMarker = null;
}

  // -----------------------------
  // Asignación de conductor
  // -----------------------------
  // Lógica para encontrar y marcar el conductor más cercano, anunciarlo en
  // la UI y liberar la asignación cuando corresponda.

function actualizarPreciosPorRuta() {
  precioMapa.textContent = calcularRangoPrecio(tipoViajeSeleccionado);
  renderizarOpcionesTarifa();
}

function calcularRangoPrecio(tipoId = tipoViajeSeleccionado) {
  const tarifa = tiposViaje[tipoId] || tiposViaje.UberX;
  const estimado = tarifa.base + rutaInfo.distanciaKm * tarifa.km + rutaInfo.duracionMin * tarifa.min;
  const minimo = redondearCinco(estimado * 0.92);
  const maximo = redondearCinco(estimado * 1.18);

  return `MXN ${minimo}-${maximo}`;
}

  // -----------------------------
  // Cálculo y renderizado de precios
  // -----------------------------
  // `calcularRangoPrecio` y `redondearCinco` encapsulan la lógica para
  // estimar un rango de tarifa basado en la distancia y la duración.

function redondearCinco(valor) {
  return Math.max(35, Math.ceil(valor / 5) * 5);
}

function actualizarResumenRuta() {
  const minutos = Math.max(1, Math.round(rutaInfo.duracionMin));
  const minimo = Math.max(1, Math.round(minutos * 0.9));
  const maximo = Math.max(minimo + 1, Math.round(minutos * 1.15));

  resumenRuta.textContent = `${rutaInfo.distanciaKm.toFixed(1)} km - ${minimo}-${maximo} min`;
}

function limpiarCampo(id) {
  document.getElementById(id).value = "";
  seleccionarModoMapa(id === "origen" ? "origen" : "destino");
}

function puedeCancelarCliente() {
  return [
    "PedidoConfirmado",
    "BuscandoConductor",
    "ConductorAsignado",
    "ConductorEnCamino"
  ].includes(estadoActual);
}

function puedeCambiarDestino() {
  return estadoActual === "PedidoEnCurso";
}

function puedeReportarEmergencia() {
  return [
    "ConductorEnCamino",
    "PedidoEnCurso"
  ].includes(estadoActual);
}

function puedeSolicitarReembolso() {
  return estadoActual === "PedidoCerrado";
}

function solicitarCancelacion() {
  if (!puedeCancelarCliente()) {
    actualizarBotonesEventos();
    return;
  }

  cancelarCliente();
}

function solicitarCambioDestino() {
  if (!puedeCambiarDestino()) {
    actualizarBotonesEventos();
    return;
  }

  cambiarDestino();
}

function solicitarEmergencia() {
  if (!puedeReportarEmergencia()) {
    actualizarBotonesEventos();
    return;
  }

  emergencia();
}

function solicitarReembolso() {
  if (!puedeSolicitarReembolso()) {
    actualizarBotonesEventos();
    return;
  }

  reembolso();
}

  // -----------------------------
  // Acciones del usuario (cancelar, cambiar destino, emergencia, reembolso)
  // -----------------------------
  // Funciones que validan si una acción es posible en el estado actual y
  // disparan los flujos correspondientes.

function cancelarCliente() {
  const permitidos = [
    "PedidoConfirmado",
    "BuscandoConductor",
    "ConductorAsignado",
    "ConductorEnCamino"
  ];

  if (permitidos.includes(estadoActual)) {
    detenerFlujo();
    cambiarEstado(
      "PedidoCanceladoPorCliente",
      "El cliente canceló el viaje."
    );
  } else {
    alert("No puedes cancelar el viaje en este estado.");
  }
}

function cambiarDestino() {
  if (estadoActual === "PedidoEnCurso") {
    recalculoDestinoEnCurso = true;
    seleccionarModoMapa("destino");
    cambiarEstado(
      "RecalcularTarifa",
      "Marca el nuevo destino en el mapa."
    );
  } else {
    alert("Solo puedes cambiar el destino cuando el viaje está en curso.");
  }
}

function emergencia() {
  const permitidos = [
    "ConductorEnCamino",
    "PedidoEnCurso"
  ];

  if (permitidos.includes(estadoActual)) {
    detenerFlujo();

    cambiarEstado(
      "PedidoEnRevision",
      "El viaje quedó en revisión por un incidente reportado."
    );
  } else {
    alert("La emergencia solo está disponible cuando el conductor va en camino o durante el viaje.");
  }
}

function reembolso() {
  if (estadoActual === "PedidoCerrado") {
    cambiarEstado(
      "ReembolsoEnRevision",
      "Tu solicitud de reembolso fue enviada a revisión."
    );
  } else {
    alert("Solo puedes solicitar reembolso cuando el pedido ya está cerrado.");
  }
}

function detenerFlujo() {
  clearInterval(intervaloFlujo);
  flujoActivo = false;
  detenerAnimacionCarro();
}

function actualizarBotonesEventos() {
  configurarBotonEvento(
    cancelEventBtn,
    puedeCancelarCliente(),
    "Disponible cuando el viaje esta confirmado, buscando conductor o el conductor va en camino."
  );
  configurarBotonEvento(
    changeDestinationEventBtn,
    puedeCambiarDestino(),
    "Disponible cuando el viaje esta en curso."
  );
  configurarBotonEvento(
    emergencyEventBtn,
    puedeReportarEmergencia(),
    "Disponible cuando el conductor va en camino o durante el viaje."
  );
  configurarBotonEvento(
    refundEventBtn,
    puedeSolicitarReembolso(),
    "Disponible cuando el pedido esta cerrado."
  );
}

function configurarBotonEvento(boton, disponible, motivo) {
  if (!boton) return;

  boton.disabled = !disponible;
  boton.title = disponible ? "" : motivo;
  boton.setAttribute("aria-disabled", String(!disponible));
}

function obtenerIndiceEstado(estado) {
  return estadosPrincipales.findIndex(([nombre]) => nombre === estado);
}

function renderizarOpcionesEstado() {
  if (!estadoPaso || !stateOptions || !backStateBtn) return;

  const indiceEstado = obtenerIndiceEstado(estadoActual);
  estadoPaso.textContent = indiceEstado === -1
    ? "Estado personalizado"
    : `Estado ${indiceEstado + 1} de ${estadosPrincipales.length}`;

  backStateBtn.disabled = historialEstados.length === 0;
  actualizarBotonesEventos();
  stateOptions.innerHTML = "";

  const acciones = obtenerAccionesEstado(indiceEstado);

  if (!acciones.length) {
    const mensaje = document.createElement("p");
    mensaje.className = "state-empty";
    mensaje.textContent = rutaCalculando
      ? "Calculando la ruta..."
      : "Selecciona origen o destino y haz clic en el mapa.";
    stateOptions.appendChild(mensaje);
    return;
  }

  acciones.forEach(accion => {
    const boton = document.createElement("button");
    boton.type = "button";
    boton.className = `state-option-btn ${accion.variante || ""}`.trim();
    boton.textContent = accion.texto;
    boton.addEventListener("click", accion.ejecutar);
    stateOptions.appendChild(boton);
  });
}

  // -----------------------------
  // Renderizado y acciones por estado
  // -----------------------------
  // `renderizarOpcionesEstado` muestra las acciones que el usuario puede
  // ejecutar en el estado actual (por ejemplo 'Avanzar estado', 'Calificar').

function obtenerAccionesEstado(indiceEstado) {
  const acciones = [];

  if (estadoActual === "PagoProcesado" && !pagoProcesadoConfirmado) {
    acciones.push({
      texto: "Decidir pago",
      variante: "primary",
      ejecutar: abrirModalProcesarPago
    });
    return acciones;
  }

  if (estadoActual === "PagoRechazado") {
    acciones.push({
      texto: "Intentar pago",
      variante: "primary",
      ejecutar: reintentarProcesarPago
    });
    return acciones;
  }

  if (estadoActual === "PedidoCalificado" && !calificacionEnviada) {
    acciones.push({
      texto: "Calificar viaje",
      variante: "primary",
      ejecutar: abrirModalCalificacion
    });
    return acciones;
  }

  if (!flujoActivo && rutaPorCallesDisponible && indiceEstado !== -1 && indiceEstado < estadosPrincipales.length - 1) {
    acciones.push({
      texto: "Avanzar estado",
      variante: "primary",
      ejecutar: avanzarEstadoManual
    });
  }

  return acciones;
}

function avanzarEstadoManual() {
  const indiceEstado = obtenerIndiceEstado(estadoActual);
  const siguienteIndice = indiceEstado === -1 ? 0 : indiceEstado + 1;
  const siguiente = estadosPrincipales[siguienteIndice];

  if (!siguiente) return;

  const [estado, descripcion] = siguiente;
  cambiarEstado(estado, obtenerDescripcionEstado(estado, descripcion));
  moverCarroPorEstado(estado);

  if (estado === "PagoProcesado" && !pagoProcesadoConfirmado) {
    abrirModalProcesarPago();
  }

  if (estado === "PedidoCalificado" && !calificacionEnviada) {
    abrirModalCalificacion();
  }
}

function moverCarroPorEstado(estado) {
  if (estado === "BuscandoConductor") {
    asignarConductorMasCercano();
  }

  if (estado === "ConductorAsignado") {
    const conductor = asignarConductorMasCercano();

    if (conductor) {
      estadoDescripcion.textContent = `${conductor.nombre} acepto tu viaje y va hacia ti.`;
    }
  }

  if (estado === "ConductorEnCamino") {
    if (!conductorAsignado) {
      asignarConductorMasCercano();
    }

    moverCarroAPunto(origenCoords, { duracion: 3000, progresoFinal: 0 });
  }

  if (estado === "PedidoEnCurso") {
    moverCarroEnRuta(0.58, { duracion: 3000 });
  }

  if (estado === "DestinoAlcanzado") {
    moverCarroEnRuta(1, { duracion: 3400 });
  }
}

function regresarEstado() {
  if (!historialEstados.length) return;

  detenerFlujo();
  cerrarModalProcesarPago();
  cerrarModalCalificacion();

  const anterior = historialEstados.pop();
  estadoActual = anterior.estado;
  estadoTitulo.textContent = formatearEstado(anterior.estado);
  estadoDescripcion.textContent = anterior.descripcion;
  progressBar.style.width = anterior.progreso || "0%";

  const indiceEstado = obtenerIndiceEstado(anterior.estado);

  if (indiceEstado !== -1) {
    indiceFlujo = indiceEstado;
  }

  renderizarOpcionesEstado();
}

  // -----------------------------
  // Helpers y utilidades generales
  // -----------------------------
  // Funciones reutilizables: normalizar lat/lng, formateo, cálculos
  // geoespaciales y conversiones.

function normalizarLatLng(latlng) {
  if (Array.isArray(latlng)) {
    return latlng;
  }

  return [latlng.lat, latlng.lng];
}

function formatearCoordenadas(coords) {
  return `${coords[0].toFixed(5)}, ${coords[1].toFixed(5)}`;
}

function calcularDistanciaKm(origen, destino) {
  const radioTierraKm = 6371;
  const lat1 = gradosARadianes(origen[0]);
  const lat2 = gradosARadianes(destino[0]);
  const deltaLat = gradosARadianes(destino[0] - origen[0]);
  const deltaLng = gradosARadianes(destino[1] - origen[1]);
  const a =
    Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
    Math.cos(lat1) * Math.cos(lat2) *
    Math.sin(deltaLng / 2) * Math.sin(deltaLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return radioTierraKm * c;
}

function gradosARadianes(grados) {
  return grados * Math.PI / 180;
}

  // Limpieza al salir: cancelar animaciones y timers activos
  window.addEventListener('beforeunload', () => {
    if (typeof cancelAnimationFrame === 'function') {
      if (animacionFlotaId) cancelAnimationFrame(animacionFlotaId);
      if (animacionCarroId) cancelAnimationFrame(animacionCarroId);
    }
    if (intervaloFlujo) clearInterval(intervaloFlujo);
  });

  // Exponer sólo las funciones necesarias para compatibilidad con handlers inline
  window.iniciarFlujo = iniciarFlujo;
  window.limpiarCampo = limpiarCampo;
  window.seleccionarModoMapa = seleccionarModoMapa;
  window.toggleMetodoPago = toggleMetodoPago;
  window.seleccionarMetodoPago = seleccionarMetodoPago;
  window.decidirProcesarPago = decidirProcesarPago;
  window.reintentarProcesarPago = reintentarProcesarPago;
  window.solicitarCancelacion = solicitarCancelacion;
  window.solicitarCambioDestino = solicitarCambioDestino;
  window.solicitarEmergencia = solicitarEmergencia;
  window.solicitarReembolso = solicitarReembolso;
  window.regresarEstado = regresarEstado;
  window.abrirModalCalificacion = abrirModalCalificacion;
  window.enviarCalificacion = enviarCalificacion;
  window.seleccionarCalificacion = seleccionarCalificacion;
  window.abrirModalProcesarPago = abrirModalProcesarPago;

})(); // end IIFE
